﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace REGISTRATION
{
    public partial class LOGIN : Form
    {
        //INITIALING DATA TO BE STORED INTO SQL DATABASE
        SqlConnection conn = new SqlConnection(@"Data Source=lab000000\SQLEXPRESS; Initial Catalog=POE; Integrated Security=true");
        SqlCommand cmd;
        SqlDataAdapter da = new SqlDataAdapter();   
        public LOGIN()
        {
            InitializeComponent();

            this.BackColor = Color.LightGray;
            this.ForeColor = Color.Black;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string login = "SELECT * FROM register WHERE Username = '" + txtUsername.Text + "' and Password= '" + txtPassword.Text + "'";
            cmd= new SqlCommand(login, conn);
            SqlDataReader dr = cmd.ExecuteReader();

            new TimeManagement().Show();
            this.Hide();

            if (dr.Read() == true)
            {
                new TimeManagement().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Welcome to Time Management");
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtPassword.Focus();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtPassword.Focus();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';              
            }
            else
            {
                txtPassword.PasswordChar = '#';             
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            new Registration().Show();
            this.Hide();
        }
    }
}
