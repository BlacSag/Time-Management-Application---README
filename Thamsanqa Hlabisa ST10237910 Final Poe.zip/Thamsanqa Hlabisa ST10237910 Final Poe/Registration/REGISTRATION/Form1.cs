﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace REGISTRATION
{
    public partial class Registration : Form
    {

        //INITIALING DATA TO BE STORED INTO SQL DATABASE
        SqlConnection conn = new SqlConnection(@"Data Source=lab000000\SQLEXPRESS; Initial Catalog=POE; Integrated Security=true"); 
        SqlCommand cmd;
        public Registration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtUsername.Text == "" && txtPassword.Text == "" && txtConfirm.Text == "")
            {
                MessageBox.Show("Username and Password field are empty", "Registration failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(txtPassword.Text == txtConfirm.Text)
            {
                conn.Open();
                cmd = new SqlCommand("Insert into register values ('"+txtUsername+"', '"+txtPassword+"')", conn);
                cmd.ExecuteNonQuery();
                conn.Close();

                txtUsername.Text = "";
                txtPassword.Text = "";
                txtConfirm.Text = "";

                MessageBox.Show("Your account has been successfully created", "Registration success", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
            }
            else
            {
                MessageBox.Show("Password does not match", "Registration failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = "";
                txtConfirm.Text = "";
                txtPassword.Focus();    
            }
        }

        private void checkPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPass.Checked)
            {
                txtPassword.PasswordChar= '\0';
                txtConfirm.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '#';
                txtConfirm.PasswordChar = '#';
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtConfirm.Text = "";
            txtPassword.Focus();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new LOGIN().Show();
            this.Hide();    
        }
    }
}
