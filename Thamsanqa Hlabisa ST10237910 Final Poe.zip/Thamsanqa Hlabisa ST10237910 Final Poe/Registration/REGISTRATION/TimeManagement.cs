﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace REGISTRATION
{
    public partial class TimeManagement : Form
    {

        //INITIALING DATA TO BE STORED INTO SQL DATABASE
        SqlConnection conn = new SqlConnection(@"Data Source=lab000000\SQLEXPRESS; Initial Catalog=POE; Integrated Security=true");
        SqlCommand cmd;
        public TimeManagement()
        {
            InitializeComponent();
        }

        private void addModule_Click(object sender, EventArgs e)
        {
            //STORING DATA INTO THE DATABASE
            conn.Open();
            cmd = new SqlCommand("insert into record values ('" + txtCode.Text + "', '" + txtName.Text + "'," +
                                " '" + txtCredits.Text + "', '" + txtHours.Text + "'," +
                                " '" + txtWeeks.Text + "')", conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data has been stored successfully!");
            conn.Close();
        }

        private void TimeManagement_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
