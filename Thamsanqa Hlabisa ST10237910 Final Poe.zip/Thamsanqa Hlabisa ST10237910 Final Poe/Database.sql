use POE
create table record
(
	id int primary key identity(1,1),
    Code varchar(50),
    Name varchar(50),
    Credits varchar(50),
    Hours varchar(50),
    Weeks varchar(50)
)
select * from record

create table register
(
	ID int primary key identity(1,1),
	Username varchar(50),
	Password varchar(50)
)

select * from register