﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace LOGIN.Areas.Identity.Data;

// Add profile data for application users by adding properties to the LOGINUser class
public class LOGINUser : IdentityUser
{
    public String firstName { get; set; }    
    public String lastName { get; set; }   
}

